//
//  ViewController.swift
//  work_Lab4
//
//  Created by iStudents on 2/6/15.
//  Copyright (c) 2015 iStudents. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    
    var one = 0
    var two = 0
    var three = 0
    
    @IBOutlet weak var None: UIButton!
    
    @IBOutlet weak var Ntwo: UIButton!
    
    @IBOutlet weak var nThree: UIButton!
    
    @IBAction func Ac1(sender: AnyObject) {
        one = one + 1
           }
    
    @IBAction func Ac2(sender: AnyObject) {
        two = two + 2
    }
    
    @IBAction func Ac3(sender: AnyObject) {
        three = three + 3
    }
    
    @IBAction func Reset(sender: AnyObject) {

    }
    
       override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

